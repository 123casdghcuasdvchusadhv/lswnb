// 星迹 · 服务器端程序（第二版：带数据仓库）
// 用 Node.js 自带的 http 模块，零第三方依赖
// 跑法：node server.js   （网页在 public/，数据存在 star-data.json）

var http = require('http');
var fs = require('fs');
var path = require('path');

var PORT = 8080;
var PUBLIC = path.join(__dirname, 'public');
var DATA_FILE = path.join(__dirname, 'star-data.json');

// 演示用钥匙：写在网页里的同步桥会带上它。
// 它挡得住路过的扫描器，挡不住有心人（钥匙就在页面源码里），正式版要换真登录。
var DEMO_TOKEN = 'xjstar2026';

var MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
  '.ico': 'image/x-icon'
};

// ---- 数据仓库（一个文件就是数据库，演示够了）----
var store = {};
try { store = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) { /* 第一次启动还没有数据文件 */ }

function saveStore() {
  fs.writeFileSync(DATA_FILE + '.tmp', JSON.stringify(store));
  fs.renameSync(DATA_FILE + '.tmp', DATA_FILE);
}

// 键名白名单：ct_开头 + 用户名（2-30位中英文数字下划线），或游客数据 ctProjects
var KEY_RE = /^(ct_[\w\u4e00-\u9fa5]{1,30}|ctProjects)$/;
var MAX_VALUE = 2 * 1024 * 1024;   // 单个键最多 2MB
var MAX_BODY = 4 * 1024 * 1024;    // 一次提交最多 4MB

function sendJSON(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

function checkToken(t) {
  return typeof t === 'string' && t.length > 0 && t === DEMO_TOKEN;
}

var server = http.createServer(function (req, res) {
  var url = req.url.split('?')[0];
  var query = req.url.indexOf('?') >= 0 ? req.url.slice(req.url.indexOf('?') + 1) : '';

  // ---- 测试接口 ----
  if (url === '/api/ping') {
    sendJSON(res, 200, { ok: true, msg: '服务器活了！', time: new Date().toLocaleString('zh-CN') });
    return;
  }

  // ---- 数据仓库 ----
  if (url === '/api/store' && req.method === 'GET') {
    var t = '';
    query.split('&').forEach(function (kv) {
      var p = kv.split('=');
      if (p[0] === 't') t = decodeURIComponent(p[1] || '');
    });
    if (!checkToken(t)) return sendJSON(res, 403, { ok: false, msg: '钥匙不对' });
    sendJSON(res, 200, { ok: true, store: store });
    return;
  }

  if (url === '/api/store' && req.method === 'POST') {
    var body = '', size = 0, tooBig = false;
    req.on('data', function (c) {
      size += c.length;
      if (size > MAX_BODY) { tooBig = true; return; }
      body += c;
    });
    req.on('end', function () {
      if (tooBig) return sendJSON(res, 413, { ok: false, msg: '提交内容太大' });
      var o;
      try { o = JSON.parse(body); } catch (e) { return sendJSON(res, 400, { ok: false, msg: '看不懂的内容' }); }
      if (!o || !checkToken(o.t)) return sendJSON(res, 403, { ok: false, msg: '钥匙不对' });
      var batch = o.batch;
      if (!batch || typeof batch !== 'object') return sendJSON(res, 400, { ok: false, msg: '缺少数据' });
      var saved = 0;
      var savedKeys = [];
      for (var k in batch) {
        if (!KEY_RE.test(k)) continue;
        if (batch[k] === null || batch[k] === undefined) {
          if (store[k] !== undefined) { delete store[k]; saved++; savedKeys.push(k + '(删)'); }
          continue;
        }
        if (typeof batch[k] !== 'string' || batch[k].length > MAX_VALUE) continue;
        if (k === 'ct_users') {
          // 账号表是「用户名→记录」字典：逐账号合并，而不是整键覆盖。
          // 防止旧快照把别台电脑刚注册的账号冲掉（历史事故：学生 11 的账号被冲丢，老师无法审批）。
          var oldU = {}, newU = {};
          try { oldU = JSON.parse(store[k] || '{}'); } catch (e) { oldU = {}; }
          try { newU = JSON.parse(batch[k] || '{}'); } catch (e) { continue; }
          for (var un in newU) oldU[un] = newU[un];
          store[k] = JSON.stringify(oldU);
        } else {
          store[k] = batch[k];
        }
        saved++;
        savedKeys.push(k);
      }
      saveStore();
      console.log('收到数据推送: ' + savedKeys.join(', ') + ' | ' + new Date().toLocaleString('zh-CN'));
      sendJSON(res, 200, { ok: true, saved: saved });
    });
    return;
  }

  // ---- 邀请码校验（学生注册时问服务器：这个码在别的设备上注册的老师那里存在吗）----
  if (url === '/api/checkcode' && req.method === 'POST') {
    var body2 = '', size2 = 0;
    req.on('data', function (c) { size2 += c.length; if (size2 > 65536) return; body2 += c; });
    req.on('end', function () {
      var o;
      try { o = JSON.parse(body2); } catch (e) { return sendJSON(res, 400, { ok: false, msg: '看不懂的内容' }); }
      if (!o || !checkToken(o.t)) return sendJSON(res, 403, { ok: false, msg: '钥匙不对' });
      var code = String(o.code || '').trim().toUpperCase();
      var found = null;
      try {
        var users = JSON.parse(store['ct_users'] || '{}');
        for (var u in users) {
          if (users[u] && users[u].role === 'teacher' && users[u].code === code) { found = u; break; }
        }
      } catch (e) { /* 数据坏了当没找到 */ }
      console.log('邀请码校验: ' + (found ? '命中 ' + found : '未找到 ' + code) + ' | ' + new Date().toLocaleString('zh-CN'));
      sendJSON(res, 200, found ? { ok: true, teacher: found } : { ok: false, msg: '这个邀请码不存在' });
    });
    return;
  }

  // ---- 网页文件 ----
  var urlPath = decodeURIComponent(url);
  if (urlPath === '/') urlPath = '/index.html';
  var file = path.normalize(path.join(PUBLIC, urlPath));
  if (file.indexOf(PUBLIC) !== 0) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('禁止访问');
    return;
  }
  fs.readFile(file, function (err, data) {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('找不到这个文件');
      return;
    }
    var ext = path.extname(file).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

server.listen(PORT, function () {
  console.log('星迹服务器已启动：');
  console.log('  网页：      http://你的公网IP:' + PORT);
  console.log('  测试接口：  http://你的公网IP:' + PORT + '/api/ping');
  console.log('  数据文件：  ' + DATA_FILE);
});