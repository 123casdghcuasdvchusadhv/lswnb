// ============ 星迹·比赛练习版服务器 ============
// 只用 Node 内置模块，无任何依赖。运行：node server.js
// 然后浏览器打开 http://localhost:8080
var http = require('http');
var fs = require('fs');
var path = require('path');

var PORT = 8080;
var TOKEN = 'xjstar2026';                              // 数据口令
var DATA = path.join(__dirname, 'data.json');          // 数据存这里

function readData() {                                  // 读数据文件
  try { return JSON.parse(fs.readFileSync(DATA, 'utf8')); }
  catch (e) { return {}; }                             // 文件不存在 = 空数据
}
function sendJSON(res, code, obj) {                    // 统一回 JSON
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

var server = http.createServer(function (req, res) {
  // 1) 读数据：GET /api/store?t=口令
  if (req.method === 'GET' && req.url.indexOf('/api/store') === 0) {
    var u = new URL(req.url, 'http://x');
    if (u.searchParams.get('t') !== TOKEN) return sendJSON(res, 403, { ok: false, msg: '口令不对' });
    return sendJSON(res, 200, { ok: true, store: readData() });
  }
  // 2) 写数据：POST /api/store  {t:口令, batch:{键:值}}
  if (req.method === 'POST' && req.url === '/api/store') {
    var body = '';
    req.on('data', function (c) { body += c; });
    req.on('end', function () {
      var b;
      try { b = JSON.parse(body); } catch (e) { return sendJSON(res, 400, { ok: false, msg: '格式不对' }); }
      if (b.t !== TOKEN) return sendJSON(res, 403, { ok: false, msg: '口令不对' });
      var store = readData();
      for (var k in (b.batch || {})) {                 // 逐条覆盖；null = 删除
        if (b.batch[k] === null) delete store[k]; else store[k] = b.batch[k];
      }
      fs.writeFileSync(DATA, JSON.stringify(store));
      sendJSON(res, 200, { ok: true, saved: Object.keys(b.batch || {}).length });
    });
    return;
  }
  // 3) 其他路径：返回 public 里的页面文件
  var file = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
  fs.readFile(file, function (err, buf) {
    if (err) { res.writeHead(404); res.end('404'); return; }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(buf);
  });
});

server.listen(PORT, function () { console.log('已启动: http://localhost:' + PORT); });
